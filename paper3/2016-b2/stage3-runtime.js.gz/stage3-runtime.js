(() => {
  'use strict';

  const sourceRows = window.EDMUND_DSE_LISTENING_2016_TRANSCRIPT?.partB || [];
  const properNameCorrections = Object.freeze({
    'Indi Wong': 'Indy Wong',
    'Lara Gao': 'Lara Gau',
    'Chang Yi Tak': 'Chang Yee Tak'
  });
  const normalizeNames = text => Object.entries(properNameCorrections)
    .reduce((copy, [from, to]) => copy.replaceAll(from, to), String(text || ''));

  const fields = [
    {
      id: '3-1', slug: 'museum-directions',
      title: 'Social History Museum (and directions)',
      titleZh: '社會歷史博物館（包括路線）',
      selector: 'textarea[data-note="3-1"]',
      headingSelector: '#page-3 .notes-form-body > h3:nth-of-type(1)',
      classification: 'listening', task: null,
      help: '這欄是完整聆聽筆記的一部分，但三項 B2 寫作均沒有要求介紹博物館或路線，因此不收入 A／B／C 證據庫。',
      transcriptStart: 8, transcriptEnd: 33
    },
    {
      id: '3-2', slug: 'farmhouse-village',
      title: 'Wang Chung Traditional Farmhouse and Village',
      titleZh: 'Wang Chung 傳統農舍與村落',
      selector: 'textarea[data-note="3-2"]',
      headingSelector: '#page-3 .notes-form-body > h3:nth-of-type(2)',
      classification: 'task', task: 'B',
      help: '這欄直接支援 Task B 的網站介紹：搬遷重建、發現地點、村落消失及菠蘿節。',
      transcriptStart: 16, transcriptEnd: 27
    },
    {
      id: '3-3', slug: 'dr-jones-talk',
      title: 'Dr Jones’ Talk',
      titleZh: 'Jones 博士的講座',
      selector: 'textarea[data-note="3-3"]',
      headingSelector: '#page-3 .notes-form-body > h3:nth-of-type(3)',
      classification: 'listening', task: null,
      help: '日期、時間和講座題目都是有效聆聽筆記，但不屬 Task A、B 或 C 的指定內容。',
      transcriptStart: 34, transcriptEnd: 36
    },
    {
      id: '3-4', slug: 'plough',
      title: 'Chang Yee Tak Plough',
      titleZh: 'Chang Yee Tak Plough',
      selector: 'textarea[data-note="3-4"]',
      headingSelector: '#page-3 .notes-form-body > h3:nth-of-type(4)',
      classification: 'task', task: 'A',
      help: '這欄支援 Task A：展覽借用目的，以及犁的年代、材質和近乎完好的保存狀況。',
      transcriptStart: 37, transcriptEnd: 41
    }
  ];

  const cues = [
    {
      id: 'museum-purpose', start: 393.91, endpoint: 496.88, field: '3-1', transcriptIndex: 9,
      quote: 'what daily life was like for ordinary people in the past',
      title: '記下社會歷史博物館的功能',
      note: 'Visitors experience daily life of ordinary people in the past.',
      noteZh: '訪客可了解昔日普通人的日常生活。',
      use: 'listening', task: null,
      help: '這是第一個完整答案點。ordinary people 是定義核心；並非帝王將相。'
    },
    {
      id: 'museum-items', start: 496.88, endpoint: 552.19, field: '3-1', transcriptIndex: 15,
      quote: 'old tables and chairs ... old telephones, computers ... old clothes',
      title: '記下館藏例子',
      note: 'Old everyday items: tables, chairs, telephones, computers and clothes.',
      noteZh: '昔日常用品：桌椅、電話、電腦和衣服。',
      use: 'listening', task: null,
      help: '保留具體例子即可；這些資料只完成筆記，不寫入三篇指定成品。'
    },
    {
      id: 'farmhouse-rebuilt', start: 552.19, endpoint: 587.99, field: '3-2', transcriptIndex: 17,
      quote: 'moved to the museum brick by brick and reconstructed inside the museum ... in 2015',
      title: '記下農舍的搬遷與重建',
      note: 'Moved brick by brick; reconstructed inside the museum in 2015.',
      noteZh: '逐磚搬遷，並於 2015 年在博物館內重建。',
      use: 'task', task: 'B',
      help: '把方法、地點和年份合併成一項完整歷程；不必抄寫「very difficult」的評語。'
    },
    {
      id: 'farmhouse-reservoir', start: 587.99, endpoint: 603.57, field: '3-2', transcriptIndex: 21,
      quote: 'at the bottom of the Wang Chung reservoir',
      title: '確認農舍的發現地點',
      note: 'Found at the bottom of Wang Chung Reservoir.',
      noteZh: '在 Wang Chung Reservoir 水塘底被發現。',
      use: 'task', task: 'B',
      help: '先聽到 a reservoir，再等 Dr Jones 具體確認為 Wang Chung Reservoir 才落筆。'
    },
    {
      id: 'village-submerged', start: 603.57, endpoint: 621.62, field: '3-2', transcriptIndex: 23,
      quote: 'disappeared under water in 1990 when they built the reservoir',
      title: '記下村落消失的年份與原因',
      note: 'Village disappeared underwater in 1990 when the reservoir was built.',
      noteZh: '1990 年興建水塘時，村落被水淹沒。',
      use: 'task', task: 'B',
      help: '事件、年份和因果要一併保留，才能解釋農舍為何出現在水塘底。'
    },
    {
      id: 'pineapple-festival', start: 621.62, endpoint: 648.12, field: '3-2', transcriptIndex: 27,
      quote: 'Farmers would offer pineapples to the god of farming',
      title: '完成菠蘿節文化筆記',
      note: 'Famous Pineapple Festival: farmers offered pineapples to the god of farming.',
      noteZh: '著名菠蘿節：農民向農神供奉菠蘿。',
      use: 'task', task: 'B',
      help: '節日名稱和儀式合在一起，才構成可放入網站介紹的完整文化事實。'
    },
    {
      id: 'museum-location', start: 648.12, endpoint: 663.68, field: '3-1', transcriptIndex: 29,
      quote: 'in South Point, close to the new MTR station',
      title: '記下博物館所在地',
      note: 'In South Point, close to the new MTR station.',
      noteZh: '位於 South Point，鄰近新港鐵站。',
      use: 'listening', task: null,
      help: '這是路線欄的第一項定位資料；有效，但不屬 A／B／C 寫作內容。'
    },
    {
      id: 'museum-mtr', start: 663.68, endpoint: 670.56, field: '3-1', transcriptIndex: 31,
      quote: 'only two minutes from South Point MTR, Exit A',
      title: '記下港鐵出口與步行時間',
      note: 'Two minutes from South Point MTR, Exit A.',
      noteZh: '由 South Point 港鐵站 A 出口步行兩分鐘。',
      use: 'listening', task: null,
      help: '保留 two minutes 和 Exit A；兩者都是實際方向資料。'
    },
    {
      id: 'museum-route', start: 670.56, endpoint: 686.66, field: '3-1', transcriptIndex: 33,
      quote: 'go straight up Reed Street to the museum',
      title: '完成 Reed Street 路線',
      note: 'From Exit A, go straight up Reed Street to the museum.',
      noteZh: '由 A 出口沿 Reed Street 直行至博物館。',
      use: 'listening', task: null,
      help: '錄音先拼出 R-E-I-D，再由 Dr Jones 說明路線；筆記採用卷面／錄音確認的 Reed Street。'
    },
    {
      id: 'talk-details', start: 686.66, endpoint: 708.83, field: '3-3', transcriptIndex: 35,
      quote: 'On April 13th, from 8 to 9 ... Farming in the New Territories',
      title: '一次記齊講座資料',
      note: 'Farming in the New Territories — Wed 13 April, 8–9 pm.',
      noteZh: '「Farming in the New Territories」— 4 月 13 日星期三晚上 8 時至 9 時。',
      use: 'listening', task: null,
      help: '同一個確認回合提供題目、日期和時間；三項都寫進原生講座欄，但不進寫作證據庫。'
    },
    {
      id: 'plough-exhibition', start: 708.83, endpoint: 737.24, field: '3-4', transcriptIndex: 37,
      quote: 'an exhibition on farming in the New Territories ... hoping to display the Chang Yee Tak Plough',
      title: '記下借犁的展覽目的',
      note: 'Farming in the New Territories exhibition hopes to display the plough.',
      noteZh: '「Farming in the New Territories」展覽希望展出該犁。',
      use: 'task', task: 'A',
      help: '這是借用目的。hoping 保留仍待借出者同意的狀態，不可寫成已獲批准。'
    },
    {
      id: 'plough-qualified-uniqueness', start: 737.24, endpoint: 793.22, field: '3-4', transcriptIndex: 41,
      quote: 'the only one from the 18th century that’s not damaged ... almost perfect condition',
      title: '等完整修正後才記獨特價值',
      note: 'Only undamaged 18th-century wood-and-iron plough; almost perfect condition.',
      noteZh: '唯一沒有損壞的十八世紀木鐵犁；保存狀況近乎完美。',
      use: 'task', task: 'A', rejectedTranscriptIndexes: [39, 40],
      help: '前面的半句和 Patty 的猜測都不完整。必須等 Dr Jones 加上 18th century、not damaged 和 almost perfect condition 的限制。'
    },
    {
      id: 'recording-end', start: 793.22, endpoint: 830.86, field: null, transcriptIndex: 43,
      quote: 'That is the end of the listening component',
      title: '錄音完結 · 準備逐句核對',
      note: null, noteZh: null,
      use: 'closure', task: null,
      help: '四個原生欄目的筆記已按錄音次序完成。下一階段逐句檢查哪些可寫、哪些只是提示或不取材。'
    }
  ];

  const reviews = [
    ['hint', null, '乙部。請查看資料檔第 2 頁的「情境」。你是 Indy Wong，在香港社會歷史博物館擔任 Lara Gau 的博物館助理。Lara 有幾項工作想請你協助完成。', '作答身分與工作關係只控制語氣及立場，不直接寫入成品。'],
    ['hint', null, '你將收聽 Patty Leung 與 Jack Jones 博士為播客節目《Nosing Around》進行的一段訪談。', '這句交代錄音來源和說話者，真正內容仍要按任務篩選。'],
    ['hint', null, '錄音播放前，你有五分鐘閱讀問答冊和資料檔，以熟習情境及各項任務。請按照問答冊和錄音中的指示完成任務。所需的全部資料均可在問答冊、', '這一行是考試程序及來源提示；句子在下一行接續。'],
    ['noise', null, '資料檔及錄音中找到。聆聽時，你可在資料檔第 3 頁做筆記。現在你有五分鐘熟習問答冊及資料檔。', '考試操作提示，不是任何成品內容。'],
    ['hint', null, '錄音即將開始。請翻到資料檔第 3 頁。', '只提示開始聆聽及筆記頁位置。'],
    ['noise', null, '本星期節目內容豐富：我們會報道成為香港本地足球死忠球迷是怎樣的體驗，並邀請香港超級聯賽十支球隊的球迷會成員到場；又會訪問新加坡酒店主管 Hav 博士，他日間在酒店工作，晚上則兼任唱片騎師。不過首先，我會訪問另一位截然不同的博士。', '足球和另一位嘉賓都是節目預告，與博物館任務無關。'],
    ['hint', null, '今天與我一起的是香港社會歷史博物館的 Jack Jones 博士。Jones 博士，歡迎再次來到《Nosing Around》。我想，這是你第三次上本節目。', '確認受訪者代表博物館；上節目次數不是寫作內容。'],
    ['noise', null, 'Patty，你好。對，能夠再次來到《Nosing Around》真好；我一向都很樂意上來。', '禮貌寒暄，沒有內容點。'],
    ['hint', null, '那麼，我們不如先談談社會歷史博物館。相信聽眾都熟悉傳統博物館的意思，但你可否向大家解釋甚麼是社會歷史博物館？', '這是筆記欄的問題引子，本身不是答案。'],
    ['listening', null, 'Patty，這個問題問得很好。社會歷史博物館是一個讓訪客體驗昔日普羅大眾日常生活的地方。', '完整定義，寫入第 1 個原生筆記欄。'],
    ['listening', null, '好的，即是昔日普羅大眾的日常生活。你所說的普羅大眾，是指像我和聽眾一樣的人，而不是國王、王后之類的人，對嗎？', '主持人重述定義並提出確認。'],
    ['mixed', null, '對，是像你我一樣的普通人，而不是國王和王后。我猜你不是女王吧。', '前句確認定義；後句只是玩笑。'],
    ['mixed', null, '嗯，也許我前世是。那麼，在社會歷史博物館可以看到甚麼東西？', '前句是玩笑；後句引出館藏例子。'],
    ['listening', null, '你會看到昔日人們使用的普通物品。與其看古代陶器和武器，我們會看祖父母家裏可能有的舊桌椅，以及舊電話、舊電腦之類的東西……', '具體館藏例子，屬完整聆聽筆記。'],
    ['listening', null, '即是普通但古舊的物品。那也包括人們以前穿的舊衣服嗎？', '補充 old clothes 這個例子。'],
    ['hint', null, '對，正是。', '只確認上一個例子，沒有獨立內容點。'],
    ['mixed', 'B', '這樣我便有興趣了。我很喜歡復古時尚物品，例如外套、首飾之類。聽說你們的博物館很大；事實上，大得連整座農舍也在館內重建了。', '個人喜好不取材；後半句把話題帶到 Task B 農舍。'],
    ['task', 'B', '對，正是 Wang Chung Traditional Farmhouse。它逐磚搬到博物館，並於 2015 年在館內重建。整項工程非常艱巨。', 'Task B 直接可用；保留搬遷方法、地點和年份，省略主觀難度評語。'],
    ['hint', null, '那麼，它原本來自哪裏？', '問題引子，答案在下一回合。'],
    ['task', 'B', '這座農舍是在一個水塘底被發現的，也就是人工湖底。', '先得到發現位置；仍要等下一句確認水塘名稱。'],
    ['hint', null, '嘩，你是說這座農舍原本在水底？', '主持人確認意思，沒有新增事實。'],
    ['task', 'B', '對，就在 Wang Chung Reservoir 的水塘底。', '具體確認發現地點，可支援 Task B。'],
    ['noise', null, '好的，我知道 Wang Chung Reservoir；我曾經到那裏遠足。', '主持人的個人經驗與指定任務無關。'],
    ['task', 'B', '你可能不知道，在興建水塘之前，那裏原本有一條村落，名為 Wang Chung Village。1990 年興建水塘時，村落被水淹沒。', '提供村落消失的事件、年份和原因。'],
    ['noise', null, '真的嗎？不，我不知道。', '主持人反應，沒有新內容。'],
    ['task', 'B', 'Wang Chung Village 從前其實頗有名，因 Wang Chung Pineapple Festival 而聞名。', 'Task B 的村落文化特色。'],
    ['noise', null, '好的，菠蘿節。我好像看過一些舊照片。', '主持人的記憶不構成所需事實。'],
    ['task', 'B', '對，很有可能。菠蘿節當年是個規模頗大的節慶；農民會把菠蘿供奉給農神。', '節日和核心儀式合成完整文化事實。'],
    ['mixed', null, '對，那就是我從照片記得的情景。好吧。啊，我記起想問甚麼了。請原諒我突然轉題：社會歷史博物館在哪裏？', '照片反應及問題本身不取材；答案在下一回合。'],
    ['listening', null, '博物館位於 South Point，鄰近新的港鐵站。', '有效路線筆記，但不屬三篇寫作。'],
    ['noise', null, '嗯，那很方便。', '主持人反應，沒有資料。'],
    ['listening', null, '對，由 South Point 港鐵站 A 出口步行只需兩分鐘。', '記下步行時間和出口。'],
    ['listening', null, '嘩，只需步行兩分鐘。是在 Reed Street 嗎？就是拼作 R-E-I-D？對，沒錯。', '確認街道名稱和拼法。'],
    ['listening', null, '在 A 出口離開車站，沿 Reed Street 一直走便到博物館。', '完成路線筆記。'],
    ['listening', null, '我聽說你將主持一場關於新界農業的講座。是在下星期三，即 4 月 13 日嗎？對，沒錯。', '確認講座題目和日期。'],
    ['listening', null, '講座在 4 月 13 日星期三晚上 8 時至 9 時舉行；正如你剛才所說，講座題目是 Farming in the New Territories。', '一次提供講座日期、時間和題目。'],
    ['mixed', null, '好的，聽起來很有趣。我很想進一步了解新界農業；各位聽眾，你們也想吧？記住，如果想參加，請不要遲到：晚上 8 時開始，9 時結束。', '只有重申的講座時間屬有效筆記；主持人的興趣和呼籲不取材。'],
    ['task', 'A', '我也想補充，博物館將舉辦一個關於新界農業的展覽；我們希望在展覽中展出 Chang Yee Tak Plough。', 'Task A 的借用目的；希望展出仍屬待批准狀態。'],
    ['hint', null, '啊，我讀書時其實讀過 Chang Yee Tak Plough；相信很多聽眾也記得在學校讀過它。我很想親眼看看。你可否向不認識它的聽眾解釋，Chang Yee Tak Plough 有甚麼特別？', '個人回憶與興趣不取材；問題引出獨特價值。'],
    ['noise', null, '它很特別，因為它是世上唯一一件木鐵犁……', '句子在限定條件出現前被打斷，不能當成答案。'],
    ['noise', null, '等等，等等。你的意思是世上沒有其他木鐵犁？', '主持人的誤解隨即被否定。'],
    ['task', 'A', '不是，Patty。我剛才還未說完。我想說的是，世上當然有很多木鐵犁，但這是唯一一件沒有損壞的十八世紀木鐵犁。這就是 Chang Yee Tak Plough 的非凡之處：它來自十八世紀，保存狀況卻近乎完美。', 'Task A 必須保留年代、材質和未損壞三重限制，並可補充近乎完好。'],
    ['noise', null, '好的，正如我所說，我想親眼看看實物。Jones 博士，謝謝你今天到來接受訪問；祝你的展覽順利。', '主持人的個人反應和節目結語不提供新內容。'],
    ['noise', null, '本試卷的聆聽部分到此結束。你有一小時十五分鐘完成 B1 或 B2 的寫作任務。時間完結時會有廣播。現在請除下耳機並關掉收音機。', '考試程序，不寫入任何成品。']
  ];

  // Golden Manual §§27 and V5-F require sentence-level projection: only the
  // exact usable answer span is coloured; every remaining word is rejected
  // with red ink on the copy (never on the speaker label).
  const highlightPhrases = Object.freeze({
    9: ['A Social History Museum is a place where visitors can experience what daily life was like for ordinary people in the past.'],
    10: ['everyday life for ordinary people in the past'],
    11: ['ordinary people like you and me, not kings and queens.'],
    13: ['ordinary items people used in the past.', "old tables and chairs you would find in your grandparents' homes.", 'Things like old telephones, computers...'],
    14: ['old clothes people used to wear'],
    16: ['rebuilt a whole farmhouse inside the museum building'],
    17: ['The Wang Chung Traditional Farmhouse. It was moved to the museum brick by brick and reconstructed inside the museum last year in 2015.'],
    19: ['The farmhouse was found at the bottom of a reservoir.'],
    21: ['at the bottom of the Wang Chung reservoir'],
    23: ['before the reservoir there was a village there, Wang Chung village. And it disappeared under water in 1990 when they built the reservoir.'],
    25: ['quite a famous village, Wang Chung, for the Wang Chung Pineapple Festival'],
    27: ['The Pineapple Festival was a pretty big festival in its day. Farmers would offer pineapples to the god of farming.'],
    29: ["It's in South Point, close to the new MTR station."],
    31: ['only two minutes from South Point MTR, Exit A.'],
    32: ['only two minutes walk.', "Is that on Reed Street, you know, as in R-E-I-D? Yes, that's right."],
    33: ['Get out at Exit A and just go straight up Reed Street to the museum.'],
    34: ['you are giving a talk on farming in the New Territories. Is that next Wednesday, the 13th of April? Yes, that\'s right.'],
    35: ['On April 13th, from 8 to 9 in the evening, Wednesday', 'Farming in the New Territories.'],
    36: ['8pm start and finish at 9pm.'],
    37: ["we're having an exhibition on farming in the New Territories at the museum? And in the exhibition, we're hoping to display the Chang Yee Tak Plough."],
    41: ["this is the only one from the 18th century that's not damaged", "It's from the 18th century, but is in almost perfect condition."]
  });

  const transcript = sourceRows.map((row, index) => {
    const review = reviews[index] || ['hint', null, '', ''];
    return Object.freeze({
      id: `part-b-turn-${String(index + 1).padStart(2, '0')}`,
      index,
      start: row.start,
      end: row.end,
      speaker: row.speaker,
      text: normalizeNames(row.text),
      sourceText: row.text,
      kind: review[0],
      task: review[1],
      translation: review[2],
      explanation: review[3],
      rejectUnhighlighted: true,
      highlightPhrases: highlightPhrases[index] || []
    });
  });

  const setupSteps = [
    {
      id: 'p3-orientation', kind: 'orientation', title: '先看四個原生筆記欄',
      sourcePage: 'Data File p.3 · Nosing Around',
      quote: 'Social History Museum · Wang Chung Traditional Farmhouse and Village · Dr Jones’ Talk · Chang Yee Tak Plough',
      translation: '四個欄目都要完成聆聽筆記；只有農舍／村落和犁的資料進入 B2 寫作。',
      explanation: '原卷第 3 頁是唯一筆記介面。Stage 3 不會建立替代工作紙，也不會把 listening-only 資料誤收進寫作證據庫。'
    },
    {
      id: 'p3-controls', kind: 'controls', title: '認識錄音控制與逐字稿',
      sourcePage: '完整 Part B 錄音 · 13:51.63',
      quote: '播放／暫停 · 停頓點 · 時間軸 · 0.5×–3× · 中文逐字稿 · 四角調整大小',
      translation: '播放器使用完整 2016 Part B MP3；正式訪談在 6:33 後開始。',
      explanation: '一般播放不會強迫捲動原卷或逐字稿。每個答案端點都會暫停；倒帶會移除未來生成筆記，但保留你自行輸入的文字。'
    }
  ];
  const cueSteps = cues.map(cue => ({
    id: `p3-cue-${cue.id}`, kind: 'cue', cueId: cue.id,
    title: cue.title,
    sourcePage: cue.field ? `Data File p.3 · ${fields.find(field => field.id === cue.field)?.title}` : '完整 Part B 錄音',
    quote: cue.quote,
    translation: cue.noteZh || '錄音完結。',
    explanation: cue.help
  }));
  const transcriptSteps = transcript.map(turn => ({
    id: `p3-review-${turn.id}`, kind: 'review', transcriptIndex: turn.index,
    title: `逐句錄音稿 · ${turn.speaker}`,
    sourcePage: `Part B ${Math.floor(turn.start / 60)}:${String(Math.floor(turn.start % 60)).padStart(2, '0')}–${Math.floor(turn.end / 60)}:${String(Math.floor(turn.end % 60)).padStart(2, '0')}`,
    quote: turn.text,
    translation: turn.translation,
    explanation: turn.explanation,
    task: turn.task,
    reviewKind: turn.kind
  }));
  const closingSteps = [
    {
      id: 'p3-final-verification', kind: 'verification', title: '最後核對四欄與兩個任務',
      sourcePage: 'Data File p.3 · 完整核對',
      quote: '4 authentic fields · 12 written notes · 13 cue stops · 44 transcript turns',
      translation: '四欄筆記完整；Task B 只取農舍／村落，Task A 只取展覽目的及犁的限定獨特價值。',
      explanation: '確認 directions 和 talk 仍留在筆記欄但不進 A／B／C；確認錯誤的「世上唯一木鐵犁」已用紅線排除。'
    },
    {
      id: 'p3-complete', kind: 'complete', title: 'Stage 3 完成',
      sourcePage: 'Super Curation · Stage 3',
      quote: 'Listening notes, cue ledger and transcript review complete.',
      translation: '聆聽筆記、精確停頓點和逐句核對已完成。',
      explanation: '本次工作到 Stage 3 為止；Stage 4 逐句取證及 Stage 5 三篇寫作保持未開放。'
    }
  ];

  const steps = [...setupSteps, ...cueSteps, ...transcriptSteps, ...closingSteps]
    .map((step, index) => Object.freeze({...step, index}));

  window.EDMUND_2016_B2_STAGE3 = Object.freeze({
    version: '2016-b2-super-curation-stage3-v1',
    schema: 2,
    architectureVersion: '2016-b2-podcast-v1-single-owner',
    storageKey: 'edmund-paper3-2016-b2-super-curation-stage3-v1',
    audio: Object.freeze({
      src: 'https://ookkxzgpdclzrrhfmvqx.supabase.co/functions/v1/public-audio-relay/DSE%20Listening%20-%20Recordings/DSE%202016%20Part%20B.mp3',
      sourceUrl: 'https://edmund-neural-audio.edmundeducation.workers.dev/DSE%20Listening%20-%20Recordings/DSE%202016%20Part%20B.mp3',
      duration: 831.63,
      sha256: '1e32a9f8d57cc8a27c72edeead5cbb6c6be04cfee37e339d25a1c482d6c676de'
    }),
    properNameCorrections,
    fields: Object.freeze(fields.map(Object.freeze)),
    cues: Object.freeze(cues.map(Object.freeze)),
    transcript: Object.freeze(transcript),
    steps: Object.freeze(steps)
  });
})();

//# sourceURL=2016-b2-stage3-data.js
(() => {
  'use strict';

  const data = window.EDMUND_2016_B2_STAGE3;
  const lesson = window.EDMUND_2016_B2_CURATION;
  const part1 = window.EDMUND_2016_B2_CURATION_DEBUG;
  const part2 = window.EDMUND_2016_B2_CURATION_STAGE2_DEBUG;
  if (!data?.steps?.length || data.transcript.length !== 44 || !part1 || !document.querySelector('#curation-next')) return;

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const make = (tag, className = '', text = '') => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text) node.textContent = text;
    return node;
  };
  const steps = data.steps.map(step => ({...step}));
  const byId = new Map(steps.map(step => [step.id, step]));
  const cuesById = new Map(data.cues.map(cue => [cue.id, cue]));
  const cueStepById = new Map(steps.filter(step => step.kind === 'cue').map(step => [step.cueId, step]));
  const fieldById = new Map(data.fields.map(field => [field.id, field]));
  const transactionLog = [];
  const stage3Panel = make('div', 'curation-stage3-actions');
  stage3Panel.id = 'curation-stage3-actions';
  stage3Panel.hidden = true;
  $('#curation-points').after(stage3Panel);

  function blankState() {
    return {
      currentId: steps[0].id,
      completedIds: [],
      bookmarks: [],
      heardCueIds: [],
      customizedCueIds: [],
      authoredNotes: {},
      helpDrafts: {},
      active: false,
      complete: false,
      transcriptTranslation: false,
      pinsShown: false,
      playbackRate: 1,
      audioTime: 0,
      migratedFrom: {
        stage1: lesson?.version || null,
        stage2: lesson?.stage2Version || null
      }
    };
  }

  function restore(value) {
    const clean = blankState();
    if (!value || typeof value !== 'object' || Array.isArray(value)) return clean;
    const knownSteps = list => [...new Set((Array.isArray(list) ? list : []).filter(id => byId.has(id)))];
    const knownCues = list => [...new Set((Array.isArray(list) ? list : []).filter(id => cuesById.has(id)))];
    clean.currentId = byId.has(value.currentId) ? value.currentId : steps[0].id;
    clean.completedIds = knownSteps(value.completedIds);
    clean.bookmarks = knownSteps(value.bookmarks);
    clean.heardCueIds = knownCues(value.heardCueIds);
    clean.customizedCueIds = knownCues(value.customizedCueIds);
    clean.active = value.active === true;
    clean.complete = value.complete === true && clean.completedIds.includes(steps.at(-1).id);
    clean.transcriptTranslation = value.transcriptTranslation === true;
    clean.pinsShown = value.pinsShown === true;
    clean.playbackRate = [0.5,0.75,1,1.25,1.5,1.75,2,2.25,2.5,2.75,3].includes(Number(value.playbackRate)) ? Number(value.playbackRate) : 1;
    clean.audioTime = Number.isFinite(value.audioTime) ? Math.max(0, Math.min(data.audio.duration, value.audioTime)) : 0;
    if (value.authoredNotes && typeof value.authoredNotes === 'object' && !Array.isArray(value.authoredNotes)) {
      clean.authoredNotes = Object.fromEntries(Object.entries(value.authoredNotes)
        .filter(([id, text]) => fieldById.has(id) && typeof text === 'string')
        .map(([id, text]) => [id, text.slice(0, 12000)]));
    }
    if (value.helpDrafts && typeof value.helpDrafts === 'object' && !Array.isArray(value.helpDrafts)) {
      clean.helpDrafts = Object.fromEntries(Object.entries(value.helpDrafts)
        .filter(([id, text]) => byId.has(id) && typeof text === 'string')
        .map(([id, text]) => [id, text.slice(0, 4000)]));
    }
    return clean;
  }

  let state = blankState();
  try {
    const saved = JSON.parse(localStorage.getItem(data.storageKey) || 'null');
    if (saved?.schema === data.schema && saved.version === data.version) state = restore(saved.state);
  } catch (error) {
    console.warn('2016 Stage 3 progress could not be restored.', error);
  }

  function persist(message = 'Stage 3 錄音、筆記與逐字稿進度已自動儲存。') {
    try {
      localStorage.setItem(data.storageKey, JSON.stringify({
        schema: data.schema,
        version: data.version,
        architectureVersion: data.architectureVersion,
        state
      }));
      if ($('#curation-save-status')) $('#curation-save-status').textContent = message;
    } catch {
      if ($('#curation-save-status')) $('#curation-save-status').textContent = '未能儲存；本次操作仍可繼續。';
    }
  }

  const fieldRefs = new Map();
  const generatedNotes = fieldId => data.cues.filter(cue =>
    cue.field === fieldId && cue.note && state.heardCueIds.includes(cue.id) && !state.customizedCueIds.includes(cue.id)
  );
  const normalizeLine = value => String(value || '').trim().replace(/[’‘]/g, "'").replace(/\s+/g, ' ');
  const noteMatches = (left, right) => normalizeLine(left) === normalizeLine(right);
  let typingCueId = null;
  let typingTimer = null;

  function extractAuthored(fieldId, value) {
    const cueNotes = data.cues.filter(cue => cue.field === fieldId && cue.note).map(cue => cue.note);
    return String(value || '').split('\n').filter(line => !cueNotes.some(note => noteMatches(line, note))).join('\n').trim();
  }

  function buildEvidencePanel(field) {
    const details = make('details', 'curation-notes-evidence');
    details.dataset.notesSection = field.id;
    const summary = make('summary', '', '顯示相關錄音內容');
    summary.setAttribute('aria-label', `${field.title}：顯示或收起相關錄音內容`);
    const body = make('div', 'curation-notes-evidence-body');
    const label = make('p', `curation-notes-scope ${field.task ? `is-task-${field.task}` : 'is-listening'}`,
      field.task ? `Task ${field.task} 寫作證據` : '完整聆聽筆記 · 不屬 A／B／C');
    const tip = make('p', '', field.help);
    const firstCue = data.cues.find(cue => cue.field === field.id);
    const play = make('button', 'curation-notes-play', firstCue ? `▶ 由 ${formatTime(firstCue.start)} 播放這欄` : '未有錄音段落');
    play.type = 'button';
    play.disabled = !firstCue;
    play.addEventListener('click', () => {
      if (!firstCue) return;
      playCue(firstCue, true);
    });
    const excerpt = make('div', 'curation-notes-excerpt');
    data.transcript.slice(field.transcriptStart, field.transcriptEnd + 1).forEach(turn => {
      const line = make('p');
      line.append(make('strong', '', `${turn.speaker}: `), document.createTextNode(turn.text));
      excerpt.append(line);
    });
    body.append(label, tip, play, excerpt);
    details.append(summary, body);
    details.addEventListener('toggle', () => {
      summary.textContent = details.open ? '收起相關錄音內容' : '顯示相關錄音內容';
    });
    return details;
  }

  for (const field of data.fields) {
    const textarea = $(field.selector);
    const heading = $(field.headingSelector);
    if (!textarea || !heading) continue;
    const headingId = `notes-heading-2016-${field.slug}`;
    const fieldId = `notes-2016-${field.slug}`;
    heading.id = headingId;
    heading.classList.add('curation-native-note-heading', field.task ? `curation-native-note-task-${field.task}` : 'curation-native-note-listening');
    let headingCopy = $('.curation-native-heading-copy', heading);
    if (!headingCopy) {
      const text = [...heading.childNodes].filter(node => node.nodeType === Node.TEXT_NODE).map(node => node.textContent).join('').trim();
      [...heading.childNodes].filter(node => node.nodeType === Node.TEXT_NODE).forEach(node => node.remove());
      headingCopy = make('span', 'curation-native-heading-copy', text || field.title);
      heading.prepend(headingCopy);
    }
    textarea.id = fieldId;
    textarea.setAttribute('aria-labelledby', headingId);
    textarea.classList.add('curation-native-note-field');
    let stateMark = $('.curation-stage3-heading-state', heading);
    if (!stateMark) {
      stateMark = make('span', `curation-stage3-heading-state ${field.task ? `curation-stage3-heading-task-${field.task}` : 'curation-stage3-heading-listening'}`);
      stateMark.setAttribute('role', 'img');
      stateMark.setAttribute('aria-label', field.task ? `Task ${field.task}` : '不屬 Task A、B 或 C');
      stateMark.textContent = field.task || '不取材';
      heading.append(stateMark);
    }
    let panel = textarea.nextElementSibling?.matches('.curation-notes-evidence') ? textarea.nextElementSibling : null;
    if (!panel) {
      panel = buildEvidencePanel(field);
      textarea.after(panel);
    }
    if (!(field.id in state.authoredNotes)) state.authoredNotes[field.id] = extractAuthored(field.id, textarea.value);
    textarea.addEventListener('input', event => {
      if (!event.isTrusted) return;
      if (typingTimer) clearInterval(typingTimer);
      typingTimer = null;
      const activeCue = typingCueId ? cuesById.get(typingCueId) : null;
      if (activeCue) state.customizedCueIds = [...new Set([...state.customizedCueIds, activeCue.id])];
      typingCueId = null;
      const lines = textarea.value.split('\n');
      for (const cue of generatedNotes(field.id)) {
        if (!lines.some(line => noteMatches(line, cue.note))) {
          state.customizedCueIds = [...new Set([...state.customizedCueIds, cue.id])];
        }
      }
      state.authoredNotes[field.id] = extractAuthored(field.id, textarea.value);
      textarea.classList.remove('curation-note-writing');
      persist('你輸入的筆記已保留；生成筆記不會覆寫。');
      render(false);
    });
    fieldRefs.set(field.id, {field, textarea, heading, panel, stateMark});
  }

  function syncNotes() {
    for (const [fieldId, ref] of fieldRefs) {
      const generated = generatedNotes(fieldId)
        .filter(cue => cue.id !== typingCueId)
        .map(cue => cue.note);
      const authored = state.authoredNotes[fieldId]?.trim() || '';
      const value = [authored, ...generated].filter(Boolean).join('\n');
      if (ref.textarea.value !== value && !(typingCueId && cuesById.get(typingCueId)?.field === fieldId)) {
        ref.textarea.value = value;
        ref.textarea.dispatchEvent(new Event('input', {bubbles: true}));
      }
    }
  }

  const player = make('div', 'curation-player curation-player-2016');
  player.id = 'curation-player-2016';
  player.hidden = true;
  player.dataset.podcastArchitecture = data.architectureVersion;
  player.innerHTML = `
    <span class="curation-player-title">2016 Part B · Podcast</span>
    <button type="button" class="curation-player-play" aria-label="播放錄音">▶</button>
    <button type="button" class="curation-player-pins-toggle" aria-pressed="false" aria-controls="curation-player-pins-2016">顯示停頓點</button>
    <span class="curation-player-timeline">
      <input class="curation-player-seek" type="range" min="0" max="${data.audio.duration}" step="0.01" value="0" aria-label="錄音進度">
      <span class="curation-player-pins" id="curation-player-pins-2016" hidden></span>
    </span>
    <output class="curation-player-time">0:00 / 13:52</output>
    <label class="curation-player-speed">速度 <select aria-label="播放速度"></select></label>
    <span class="curation-player-status" role="status"></span>`;
  const audio = document.createElement('audio');
  audio.src = data.audio.src;
  audio.preload = 'metadata';
  audio.setAttribute('aria-label', '2016 DSE Paper 3 Part B 完整錄音');
  audio.hidden = true;
  player.append(audio);
  const speed = $('.curation-player-speed select', player);
  for (const rate of [0.5,0.75,1,1.25,1.5,1.75,2,2.25,2.5,2.75,3]) {
    const option = make('option', '', `${rate}×`);
    option.value = String(rate);
    speed.append(option);
  }
  speed.value = String(state.playbackRate);
  audio.playbackRate = state.playbackRate;
  const pins = $('.curation-player-pins', player);
  for (const [index, cue] of data.cues.entries()) {
    const pin = make('span', 'curation-player-pin');
    pin.dataset.cueId = cue.id;
    pin.style.left = `${(cue.endpoint / data.audio.duration) * 100}%`;
    pin.setAttribute('role', 'img');
    pin.setAttribute('aria-label', `${index + 1}. ${cue.title} · ${formatTime(cue.endpoint)}`);
    pin.title = pin.getAttribute('aria-label');
    pins.append(pin);
  }

  const transcriptWindow = make('aside', 'curation-transcript-window curation-transcript-window-2016');
  transcriptWindow.id = 'curation-transcript-window-2016';
  transcriptWindow.hidden = true;
  transcriptWindow.setAttribute('aria-label', '2016 Part B 浮動錄音稿');
  transcriptWindow.innerHTML = `
    <div class="curation-transcript-window-head">
      <strong>錄音稿 · 自由捲動</strong>
      <button type="button" class="curation-transcript-translate" aria-pressed="false">中文對照</button>
      <span>拖曳移動 · 四角調整大小</span>
    </div>
    <div class="curation-transcript-window-body"></div>`;
  const transcriptBody = $('.curation-transcript-window-body', transcriptWindow);
  const transcriptRows = [];

  function appendSemanticText(container, turn) {
    const ranges = [];
    const pointClass = turn.task
      ? `curation-transcript-inline-task curation-transcript-inline-task-${turn.task}`
      : 'curation-transcript-inline-listening';
    const addRanges = (phrases, className) => {
      for (const phrase of phrases || []) {
        const at = turn.text.indexOf(phrase);
        if (at < 0) {
          console.error('2016 Stage 3 transcript phrase audit failed.', {turn: turn.id, phrase});
          continue;
        }
        ranges.push({start: at, end: at + phrase.length, className});
      }
    };
    addRanges(turn.highlightPhrases, pointClass);
    ranges.sort((a, b) => a.start - b.start || b.end - a.end);
    let cursor = 0;
    for (const range of ranges) {
      if (range.start < cursor) continue;
      if (range.start > cursor) {
        container.append(make('span', 'curation-transcript-inline-noise', turn.text.slice(cursor, range.start)));
      }
      container.append(make('span', range.className, turn.text.slice(range.start, range.end)));
      cursor = range.end;
    }
    if (cursor < turn.text.length) {
      container.append(make('span', 'curation-transcript-inline-noise', turn.text.slice(cursor)));
    }
  }

  for (const turn of data.transcript) {
    const row = make('article', `curation-transcript-turn curation-transcript-${turn.kind}`);
    row.dataset.transcriptIndex = String(turn.index);
    if (turn.task) row.dataset.task = turn.task;
    const speaker = make('strong', 'curation-transcript-speaker', turn.speaker);
    const copy = make('p', 'curation-transcript-copy');
    appendSemanticText(copy, turn);
    const translation = make('p', 'curation-transcript-translation', turn.translation);
    translation.lang = 'zh-Hant';
    const time = make('time', '', `${formatTime(turn.start)}–${formatTime(turn.end)}`);
    row.append(speaker, time, copy, translation);
    transcriptBody.append(row);
    transcriptRows.push(row);
  }
  for (const corner of ['nw','ne','sw','se']) {
    const handle = make('span', `curation-resize-handle curation-resize-${corner}`);
    handle.dataset.resize = corner;
    handle.setAttribute('role', 'separator');
    handle.setAttribute('aria-label', `調整錄音稿大小 · ${corner}`);
    transcriptWindow.append(handle);
  }

  const bank = make('aside', 'curation-stage3-bank');
  bank.id = 'curation-stage3-bank';
  bank.hidden = true;
  bank.setAttribute('aria-label', 'Stage 3 錄音證據庫');
  bank.innerHTML = `
    <header><h2>錄音證據庫</h2><p>只收已聽到且可用於寫作的內容；路線與講座仍留在筆記表。</p></header>
    <details data-task="A" open><summary><span>Task A · 回覆電郵</span><strong data-count>0 點</strong></summary><ol></ol></details>
    <details data-task="B" open><summary><span>Task B · 網站介紹</span><strong data-count>0 點</strong></summary><ol></ol></details>
    <details data-task="C"><summary><span>Task C · 報告主體</span><strong data-count>0 點</strong></summary><ol></ol></details>
    <section class="curation-listening-only-summary"><h3>完整聆聽筆記</h3><p><strong data-count>0</strong> 個 listening-only 停頓點已完成，不進寫作證據庫。</p></section>`;
  document.body.append(player, transcriptWindow, bank);

  function formatTime(value) {
    const whole = Math.max(0, Math.floor(Number.isFinite(value) ? value : 0));
    return `${Math.floor(whole / 60)}:${String(whole % 60).padStart(2, '0')}`;
  }

  const current = () => byId.get(state.currentId) || steps[0];
  const isCurationOpen = () => $('#curation-toggle')?.getAttribute('aria-pressed') === 'true';
  const isVisible = () => state.active && isCurationOpen();
  let activeBoundaryCueId = null;
  let pointerOperation = null;

  function nextBoundary(after = audio.currentTime) {
    return data.cues.find(cue => cue.endpoint > after + 0.04) || null;
  }

  function armNextBoundary(after = audio.currentTime) {
    activeBoundaryCueId = nextBoundary(after)?.id || null;
    return activeBoundaryCueId;
  }

  function syncPlayer() {
    const duration = Number.isFinite(audio.duration) ? audio.duration : data.audio.duration;
    const time = Number.isFinite(audio.currentTime) ? audio.currentTime : state.audioTime;
    $('.curation-player-play', player).textContent = audio.paused ? '▶' : '❚❚';
    $('.curation-player-play', player).setAttribute('aria-label', audio.paused ? '播放錄音' : '暫停錄音');
    $('.curation-player-seek', player).max = String(duration);
    $('.curation-player-seek', player).value = String(Math.min(time, duration));
    $('.curation-player-time', player).textContent = `${formatTime(time)} / ${formatTime(duration)}`;
    $$('.curation-player-pin', player).forEach(pin => pin.classList.toggle('is-heard', state.heardCueIds.includes(pin.dataset.cueId)));
    pins.hidden = !state.pinsShown;
    const pinToggle = $('.curation-player-pins-toggle', player);
    pinToggle.setAttribute('aria-pressed', String(state.pinsShown));
    pinToggle.textContent = state.pinsShown ? '隱藏停頓點' : '顯示停頓點';
  }

  function renderTranscript(focus = false) {
    const step = current();
    const reviewIndex = step.kind === 'review' ? step.transcriptIndex : -1;
    const reviewStart = steps.find(item => item.kind === 'review')?.index ?? Infinity;
    const inReview = step.index >= reviewStart;
    const cueIndexes = new Set();
    for (const cue of data.cues) {
      if (!state.heardCueIds.includes(cue.id)) continue;
      cueIndexes.add(cue.transcriptIndex);
      for (const rejected of cue.rejectedTranscriptIndexes || []) cueIndexes.add(rejected);
    }
    transcriptRows.forEach((row, index) => {
      row.classList.toggle('is-audio-reached', cueIndexes.has(index));
      row.classList.toggle('is-reviewed', inReview && index <= reviewIndex);
      row.classList.toggle('is-current', step.kind === 'review' && index === reviewIndex);
    });
    transcriptWindow.classList.toggle('show-translation', state.transcriptTranslation);
    const translate = $('.curation-transcript-translate', transcriptWindow);
    translate.setAttribute('aria-pressed', String(state.transcriptTranslation));
    translate.textContent = state.transcriptTranslation ? '隱藏中文' : '中文對照';
    if (focus && step.kind === 'review') {
      const row = transcriptRows[step.transcriptIndex];
      if (row) row.scrollIntoView({block: 'center', behavior: 'auto'});
    }
  }

  function renderBank() {
    for (const task of ['A','B','C']) {
      const group = $(`#curation-stage3-bank [data-task="${task}"]`);
      const list = $('ol', group);
      const visible = data.cues.filter(cue => cue.task === task && state.heardCueIds.includes(cue.id));
      list.replaceChildren(...visible.map(cue => {
        const item = make('li');
        const button = make('button', '', cue.note);
        button.type = 'button';
        button.addEventListener('click', () => setCurrent(cueStepById.get(cue.id).index, true));
        item.append(button, make('small', '', `${fieldById.get(cue.field)?.title} · ${formatTime(cue.endpoint)}`));
        return item;
      }));
      $('[data-count]', group).textContent = `${visible.length} 點`;
    }
    const listeningCount = data.cues.filter(cue => cue.use === 'listening' && state.heardCueIds.includes(cue.id)).length;
    $('.curation-listening-only-summary [data-count]', bank).textContent = String(listeningCount);
  }

  function rebuildSelects(step) {
    $('#curation-step-jump').replaceChildren(...steps.map(item => {
      const option = make('option', '', `${item.index + 1}. ${item.title}`);
      option.value = item.id;
      option.selected = item.id === step.id;
      return option;
    }));
    const placeholder = make('option', '', '選擇書籤');
    placeholder.value = '';
    $('#curation-bookmark-jump').replaceChildren(placeholder, ...state.bookmarks.map(id => {
      const item = byId.get(id);
      const option = make('option', '', `${item.index + 1}. ${item.title}`);
      option.value = id;
      return option;
    }));
  }

  function renderRail() {
    const stage1 = $('.curation-stage-item[data-stage="instruction"]');
    const stage2 = $('.curation-stage-item[data-stage="categorize"]');
    const stage3 = $('.curation-stage-item[data-stage="podcast"]');
    for (const item of $$('.curation-stage-item')) {
      item.classList.remove('active');
      item.setAttribute('aria-current', 'false');
    }
    stage1.classList.toggle('complete', part1.getState().stageComplete === true);
    $('.curation-stage-dot', stage1).textContent = part1.getState().stageComplete ? '✓' : '1';
    stage2.classList.toggle('complete', part2?.getState().complete === true);
    $('.curation-stage-dot', stage2).textContent = part2?.getState().complete ? '✓' : '2';
    stage3.disabled = false;
    stage3.classList.add('active');
    stage3.classList.toggle('complete', state.complete);
    stage3.setAttribute('aria-current', 'step');
    $('.curation-stage-dot', stage3).textContent = state.complete ? '✓' : '3';
    $('.curation-stage-count', stage3).textContent = `${state.completedIds.length}/${steps.length}`;
    for (const id of ['data','writing']) {
      const item = $(`.curation-stage-item[data-stage="${id}"]`);
      item.disabled = true;
      $('.curation-stage-count', item).textContent = '未開放';
    }
  }

  function renderActions(step) {
    stage3Panel.replaceChildren();
    if (step.kind === 'controls') {
      const full = make('button', 'curation-stage3-small', '▶ 完整由 0:00 播放');
      full.type = 'button';
      full.addEventListener('click', () => playFrom(0));
      const interview = make('button', 'curation-stage3-small', '▶ 由正式訪問 6:33 播放');
      interview.type = 'button';
      interview.addEventListener('click', () => playFrom(393.91));
      stage3Panel.append(full, interview);
    } else if (step.kind === 'cue') {
      const cue = cuesById.get(step.cueId);
      const replay = make('button', 'curation-stage3-small', `↻ 重聽至 ${formatTime(cue.endpoint)}`);
      replay.type = 'button';
      replay.addEventListener('click', () => playCue(cue, true));
      stage3Panel.append(replay);
    } else if (step.kind === 'review') {
      const turn = data.transcript[step.transcriptIndex];
      const play = make('button', 'curation-stage3-small', `▶ 播放這句 ${formatTime(turn.start)}`);
      play.type = 'button';
      play.addEventListener('click', () => {
        audio.currentTime = turn.start;
        activeBoundaryCueId = null;
        audio.play().catch(showAudioError);
      });
      stage3Panel.append(play);
    }
  }

  function typeLabel(step) {
    if (step.kind === 'cue') {
      const cue = cuesById.get(step.cueId);
      return cue.task ? `Task ${cue.task} · 錄音答案` : cue.use === 'closure' ? '錄音完結' : '完整聆聽筆記 · 不進寫作';
    }
    if (step.kind === 'review') {
      if (step.task) return `Task ${step.task} · 可用錄音內容`;
      if (step.reviewKind === 'noise') return 'Type 6 · 不取材';
      if (step.reviewKind === 'listening') return '完整聆聽筆記 · 不進寫作';
      if (step.reviewKind === 'mixed') return '混合內容 · 只取精確片段';
      return 'Type 5 · 提示／語境';
    }
    if (step.kind === 'verification') return 'Stage 3 · 最後核對';
    if (step.kind === 'complete') return 'Stage 3 · 完成';
    return 'Stage 3 · 聆聽準備';
  }

  function targetFor(step) {
    if (step.kind === 'cue') {
      const cue = cuesById.get(step.cueId);
      return cue.field ? fieldRefs.get(cue.field)?.textarea : $('#page-3 .conference-notes h2');
    }
    if (step.kind === 'review') return transcriptRows[step.transcriptIndex];
    return $('#page-3 .conference-notes h2');
  }

  function render(focus = false) {
    if (!isVisible()) return;
    const step = current();
    document.body.classList.add('curation-stage3-active', 'curation-podcast-active');
    stage3Panel.hidden = false;
    player.hidden = false;
    transcriptWindow.hidden = false;
    bank.hidden = false;
    $('.curation-dock > header span').textContent = '2016 B2 · SUPER CURATION · STAGE 3';
    $('#curation-step-id').textContent = `STEP ID · ${step.id}`;
    $('#curation-step-count').textContent = `步驟 ${step.index + 1} / ${steps.length} · 完成 ${state.completedIds.length} / ${steps.length}`;
    $('#curation-progress').max = steps.length;
    $('#curation-progress').value = state.completedIds.length;
    $('#curation-progress').setAttribute('aria-label', 'Stage 3 完成進度');
    $('#curation-source').textContent = step.sourcePage;
    $('#curation-title').textContent = step.title;
    $('#curation-quote').textContent = step.quote;
    $('#curation-translation').textContent = step.translation;
    $('#curation-type').textContent = typeLabel(step);
    $('#curation-explanation').textContent = step.explanation;
    $('#curation-points').hidden = true;
    $('#curation-prev').disabled = step.index === 0;
    const cuePending = step.kind === 'cue' && (!state.heardCueIds.includes(step.cueId) || typingCueId === step.cueId);
    $('#curation-next').disabled = cuePending || (state.complete && step.kind === 'complete');
    $('#curation-next').textContent = state.complete && step.kind === 'complete' ? 'Stage 3 已完成 ✓' : step.kind === 'complete' ? '完成 Stage 3 ✓' : '下一步 →';
    $('#curation-bookmark').textContent = state.bookmarks.includes(step.id) ? '★' : '☆';
    $('#curation-bookmark').setAttribute('aria-pressed', String(state.bookmarks.includes(step.id)));
    $('#curation-bookmark-count').textContent = state.bookmarks.length ? `${state.bookmarks.length} 個書籤` : '尚無書籤';
    $('#curation-spotlight').checked = false;
    rebuildSelects(step);
    renderRail();
    renderActions(step);
    syncNotes();
    syncPlayer();
    renderTranscript(focus);
    renderBank();
    persist(state.complete ? 'Stage 3 已完成；Stage 4–5 保持未開放。' : undefined);
    if (focus && step.kind !== 'review') targetFor(step)?.scrollIntoView({block: 'center', inline: 'nearest', behavior: 'auto'});
  }

  function rewindToStep(step) {
    state.completedIds = state.completedIds.filter(id => byId.get(id)?.index <= step.index);
    state.complete = false;
    if (step.index < steps.find(item => item.kind === 'review').index) {
      const cueStep = step.kind === 'cue' ? step : null;
      const keepThrough = cueStep ? data.cues.findIndex(cue => cue.id === cueStep.cueId) : -1;
      const kept = data.cues.slice(0, keepThrough + 1).map(cue => cue.id);
      state.heardCueIds = state.heardCueIds.filter(id => kept.includes(id));
      audio.pause();
      const cutoff = keepThrough >= 0 ? data.cues[keepThrough].endpoint : 0;
      if (audio.readyState >= 1) audio.currentTime = cutoff;
      state.audioTime = cutoff;
      activeBoundaryCueId = nextBoundary(cutoff)?.id || null;
      cancelTyping();
    }
  }

  function setCurrent(index, focus = true, rewind = false) {
    const target = steps[Math.max(0, Math.min(steps.length - 1, index))];
    if (rewind && target.index < current().index) rewindToStep(target);
    state.currentId = target.id;
    render(focus);
  }

  function cancelTyping() {
    if (typingTimer) clearInterval(typingTimer);
    typingTimer = null;
    if (typingCueId) {
      const cue = cuesById.get(typingCueId);
      fieldRefs.get(cue?.field)?.textarea.classList.remove('curation-note-writing');
    }
    typingCueId = null;
  }

  function writeCueNote(cue) {
    if (!cue.field || !cue.note || state.customizedCueIds.includes(cue.id)) return Promise.resolve();
    const ref = fieldRefs.get(cue.field);
    if (!ref) return Promise.reject(new Error(`Missing authentic note field ${cue.field}`));
    if (ref.textarea.value.split('\n').some(line => noteMatches(line, cue.note))) {
      typingCueId = null;
      ref.textarea.classList.remove('curation-note-writing');
      return Promise.resolve();
    }
    const prefix = ref.textarea.value.trimEnd();
    const startValue = prefix ? `${prefix}\n` : '';
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) {
      ref.textarea.value = startValue + cue.note;
      ref.textarea.dispatchEvent(new Event('input', {bubbles: true}));
      typingCueId = null;
      return Promise.resolve();
    }
    return new Promise(resolve => {
      if (typingTimer) clearInterval(typingTimer);
      typingTimer = null;
      typingCueId = cue.id;
      ref.textarea.classList.add('curation-note-writing');
      let count = 0;
      typingTimer = setInterval(() => {
        count = Math.min(cue.note.length, count + 5);
        ref.textarea.value = startValue + cue.note.slice(0, count);
        ref.textarea.dispatchEvent(new Event('input', {bubbles: true}));
        ref.textarea.scrollTop = ref.textarea.scrollHeight;
        if (count >= cue.note.length) {
          clearInterval(typingTimer);
          typingTimer = null;
          typingCueId = null;
          ref.textarea.classList.remove('curation-note-writing');
          resolve();
        }
      }, 24);
    });
  }

  async function commitCue(cue) {
    audio.pause();
    if (audio.readyState >= 1) audio.currentTime = cue.endpoint;
    state.audioTime = cue.endpoint;
    if (!state.heardCueIds.includes(cue.id)) state.heardCueIds.push(cue.id);
    const step = cueStepById.get(cue.id);
    state.currentId = step.id;
    activeBoundaryCueId = null;
    if (cue.note && !state.customizedCueIds.includes(cue.id)) typingCueId = cue.id;
    const record = {
      cueId: cue.id,
      index: data.cues.findIndex(item => item.id === cue.id),
      audioTime: cue.endpoint,
      endpoint: cue.endpoint,
      destination: cue.field,
      text: cue.note,
      architectureVersion: data.architectureVersion,
      releaseSha: document.documentElement.dataset.releaseSha || null
    };
    transactionLog.push(record);
    window.dispatchEvent(new CustomEvent('edmund:2016-stage3-cue', {detail: record}));
    render(false);
    try {
      await writeCueNote(cue);
      syncNotes();
      persist(`錄音停在 ${formatTime(cue.endpoint)}；筆記已寫入原生欄目。`);
    } catch (error) {
      console.error(error);
      $('.curation-player-status', player).textContent = `找不到筆記欄 ${cue.field || ''}；未寫入其他欄目。`;
    }
    render(false);
  }

  function playFrom(time) {
    if (audio.readyState >= 1) audio.currentTime = time;
    else audio.addEventListener('loadedmetadata', () => { audio.currentTime = time; }, {once: true});
    activeBoundaryCueId = nextBoundary(time)?.id || null;
    audio.play().catch(showAudioError);
  }

  function playCue(cue, replay = false) {
    cancelTyping();
    const start = replay ? cue.start : Math.max(cue.start, Math.min(audio.currentTime || cue.start, cue.endpoint - 0.05));
    if (audio.readyState >= 1) audio.currentTime = start;
    else audio.addEventListener('loadedmetadata', () => { audio.currentTime = start; }, {once: true});
    activeBoundaryCueId = cue.id;
    state.currentId = cueStepById.get(cue.id).id;
    render(false);
    audio.play().catch(showAudioError);
  }

  function showAudioError() {
    $('.curation-player-status', player).textContent = '錄音未能播放；可重試，逐字稿仍可檢查，但不會把停頓點標成已聽。';
  }

  function deliberateSeek(time) {
    cancelTyping();
    audio.pause();
    audio.currentTime = Math.max(0, Math.min(data.audio.duration, time));
    state.audioTime = audio.currentTime;
    state.heardCueIds = data.cues.filter(cue => cue.endpoint <= audio.currentTime + 0.12).map(cue => cue.id);
    activeBoundaryCueId = nextBoundary(audio.currentTime)?.id || null;
    persist('已按新播放位置重建停頓點、生成筆記與逐字稿標記。');
    render(false);
  }

  audio.addEventListener('loadedmetadata', () => {
    audio.currentTime = Math.min(state.audioTime, audio.duration || data.audio.duration);
    audio.playbackRate = state.playbackRate;
    syncPlayer();
  });
  audio.addEventListener('timeupdate', () => {
    state.audioTime = audio.currentTime;
    const cue = activeBoundaryCueId ? cuesById.get(activeBoundaryCueId) : null;
    if (cue && audio.currentTime >= cue.endpoint - 0.06) {
      activeBoundaryCueId = null;
      void commitCue(cue);
      return;
    }
    syncPlayer();
  });
  audio.addEventListener('play', () => {
    if (!activeBoundaryCueId) armNextBoundary(audio.currentTime);
    $('.curation-player-status', player).textContent = '';
    syncPlayer();
  });
  audio.addEventListener('pause', () => {
    state.audioTime = audio.currentTime;
    syncPlayer();
    persist();
  });
  audio.addEventListener('error', showAudioError);
  audio.addEventListener('ended', () => {
    const endCue = data.cues.at(-1);
    if (!state.heardCueIds.includes(endCue.id)) void commitCue(endCue);
  });
  $('.curation-player-play', player).addEventListener('click', () => {
    if (audio.paused) {
      if (!activeBoundaryCueId) armNextBoundary(audio.currentTime);
      audio.play().catch(showAudioError);
    } else audio.pause();
  });
  $('.curation-player-pins-toggle', player).addEventListener('click', () => {
    state.pinsShown = !state.pinsShown;
    syncPlayer();
    persist();
  });
  $('.curation-player-seek', player).addEventListener('input', event => {
    $('.curation-player-time', player).textContent = `${formatTime(Number(event.target.value))} / ${formatTime(Number(event.target.max))}`;
  });
  $('.curation-player-seek', player).addEventListener('change', event => deliberateSeek(Number(event.target.value)));
  speed.addEventListener('change', () => {
    state.playbackRate = Number(speed.value);
    audio.playbackRate = state.playbackRate;
    persist();
  });
  $('.curation-transcript-translate', transcriptWindow).addEventListener('click', () => {
    state.transcriptTranslation = !state.transcriptTranslation;
    renderTranscript(false);
    persist();
  });

  function fitTranscriptWindow() {
    if (transcriptWindow.hidden) return;
    if (innerWidth <= 700) {
      transcriptWindow.removeAttribute('data-moved');
      for (const property of ['left','top','right','width','height']) transcriptWindow.style.removeProperty(property);
      return;
    }
    if (!transcriptWindow.dataset.moved) return;
    const rect = transcriptWindow.getBoundingClientRect();
    transcriptWindow.style.left = `${Math.max(4, Math.min(rect.left, innerWidth - rect.width - 4))}px`;
    transcriptWindow.style.top = `${Math.max(4, Math.min(rect.top, innerHeight - rect.height - 4))}px`;
  }
  transcriptWindow.addEventListener('pointerdown', event => {
    const corner = event.target.dataset.resize;
    const head = event.target.closest('.curation-transcript-window-head');
    if ((!corner && !head) || event.target.closest('button,input,select')) return;
    event.preventDefault();
    const rect = transcriptWindow.getBoundingClientRect();
    pointerOperation = {corner, move: !!head, x: event.clientX, y: event.clientY, left: rect.left, top: rect.top, width: rect.width, height: rect.height};
    transcriptWindow.dataset.moved = '1';
    transcriptWindow.setPointerCapture(event.pointerId);
  });
  transcriptWindow.addEventListener('pointermove', event => {
    if (!pointerOperation) return;
    const operation = pointerOperation;
    const dx = event.clientX - operation.x;
    const dy = event.clientY - operation.y;
    let {left, top, width, height} = operation;
    if (operation.move) {
      left += dx;
      top += dy;
    } else {
      if (operation.corner.includes('w')) { left += dx; width -= dx; } else width += dx;
      if (operation.corner.includes('n')) { top += dy; height -= dy; } else height += dy;
      if (width < 300) { if (operation.corner.includes('w')) left -= 300 - width; width = 300; }
      if (height < 180) { if (operation.corner.includes('n')) top -= 180 - height; height = 180; }
    }
    width = Math.min(width, innerWidth - 8);
    height = Math.min(height, innerHeight - 8);
    left = Math.max(4, Math.min(left, innerWidth - width - 4));
    top = Math.max(4, Math.min(top, innerHeight - height - 4));
    Object.assign(transcriptWindow.style, {left: `${left}px`, top: `${top}px`, width: `${width}px`, height: `${height}px`, right: 'auto'});
  });
  transcriptWindow.addEventListener('pointerup', () => { pointerOperation = null; });
  transcriptWindow.addEventListener('lostpointercapture', () => { pointerOperation = null; });

  function suspendVisuals() {
    cancelTyping();
    audio.pause();
    document.body.classList.remove('curation-stage3-active', 'curation-podcast-active');
    stage3Panel.hidden = true;
    player.hidden = true;
    transcriptWindow.hidden = true;
    bank.hidden = true;
  }

  function enter() {
    if (part2?.getState().active) part2.leave();
    part1.setSpotlight(false);
    state.active = true;
    persist('已進入 Stage 3；Stage 1/2 進度保持不變。');
    render(true);
  }

  function leave({switchStage = true} = {}) {
    if (switchStage) state.active = false;
    suspendVisuals();
    persist('Stage 3 離開位置已儲存。');
  }

  const stopWhenActive = event => {
    if (!state.active) return false;
    event.preventDefault();
    event.stopImmediatePropagation();
    return true;
  };

  $('#curation-next').addEventListener('click', event => {
    if (!stopWhenActive(event)) return;
    const step = current();
    if (step.kind === 'cue' && (!state.heardCueIds.includes(step.cueId) || typingCueId === step.cueId)) return;
    if (!state.completedIds.includes(step.id)) state.completedIds.push(step.id);
    if (step.kind === 'complete') {
      state.complete = true;
      render(false);
      return;
    }
    const next = steps[Math.min(steps.length - 1, step.index + 1)];
    state.currentId = next.id;
    render(next.kind === 'review');
    if (next.kind === 'cue' && !state.heardCueIds.includes(next.cueId)) playCue(cuesById.get(next.cueId));
  }, true);
  $('#curation-prev').addEventListener('click', event => {
    if (!stopWhenActive(event)) return;
    setCurrent(current().index - 1, true, true);
  }, true);
  $('#curation-step-jump').addEventListener('change', event => {
    if (!stopWhenActive(event)) return;
    const step = byId.get(event.target.value);
    if (step) setCurrent(step.index, true, true);
  }, true);
  $('#curation-bookmark-jump').addEventListener('change', event => {
    if (!stopWhenActive(event)) return;
    const step = byId.get(event.target.value);
    if (step) setCurrent(step.index, true, true);
  }, true);
  $('#curation-bookmark').addEventListener('click', event => {
    if (!stopWhenActive(event)) return;
    const id = current().id;
    state.bookmarks = state.bookmarks.includes(id) ? state.bookmarks.filter(item => item !== id) : [...state.bookmarks, id];
    render(false);
  }, true);
  $('#curation-spotlight').addEventListener('change', event => {
    if (!stopWhenActive(event)) return;
    event.target.checked = false;
    $('#curation-save-status').textContent = 'Stage 3 的播放器與逐字稿不使用聚光燈遮罩。';
  }, true);
  $('#curation-help').addEventListener('click', event => {
    if (!stopWhenActive(event)) return;
    const step = current();
    $('#curation-help-context').textContent = `${step.sourcePage} · ${step.title} · STEP ID ${step.id}`;
    $('#curation-help-guidance').textContent = step.explanation;
    $('#curation-help-question').value = state.helpDrafts[step.id] || '';
    $('#curation-help-status').textContent = '問題草稿只會儲存在此瀏覽器，不會自動傳送。';
    const dialog = $('.curation-help-dialog');
    if (typeof dialog.showModal === 'function') dialog.showModal(); else dialog.open = true;
  }, true);
  $('#curation-help-form').addEventListener('submit', event => {
    if (!state.active) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    const value = $('#curation-help-question').value.trim();
    if (value) state.helpDrafts[current().id] = value; else delete state.helpDrafts[current().id];
    persist('問題草稿已儲存於此瀏覽器；未有傳送。');
    $('#curation-help-status').textContent = '問題草稿已儲存於此瀏覽器；未有傳送。';
  }, true);

  $('.curation-stage-item[data-stage="podcast"]').addEventListener('click', event => {
    event.preventDefault();
    event.stopImmediatePropagation();
    enter();
  }, true);
  $('.curation-stage-item[data-stage="instruction"]').addEventListener('click', event => {
    if (!state.active) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    leave({switchStage: true});
    part1.goById(part1.getState().stepId);
  }, true);
  document.addEventListener('keydown', event => {
    if (!state.active || !isCurationOpen() || /INPUT|TEXTAREA|SELECT/.test(event.target.tagName) || $('.curation-help-dialog').open) return;
    if (!['ArrowLeft','ArrowRight'].includes(event.key)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (event.key === 'ArrowLeft') setCurrent(current().index - 1, true, true);
    else if (!$('#curation-next').disabled) $('#curation-next').click();
  }, true);
  window.addEventListener('resize', fitTranscriptWindow);
  window.addEventListener('pagehide', () => {
    state.audioTime = audio.currentTime;
    persist();
  });
  $('#curation-close').addEventListener('click', () => {
    if (!state.active) return;
    queueMicrotask(() => leave({switchStage: false}));
  }, true);
  $('#curation-toggle').addEventListener('click', () => {
    queueMicrotask(() => {
      if (!state.active) return;
      if (isCurationOpen()) enter();
      else leave({switchStage: false});
    });
  });

  window.EDMUND_2016_B2_CURATION_STAGE3_DEBUG = Object.freeze({
    version: data.version,
    architectureVersion: data.architectureVersion,
    storageKey: data.storageKey,
    steps: steps.map(step => ({...step})),
    fields: data.fields,
    cues: data.cues,
    transcript: data.transcript,
    transactionLog,
    getState: () => ({...state, position: current().index, stepId: current().id, typingCueId, activeBoundaryCueId, audioTime: audio.currentTime}),
    enter,
    leave: () => leave({switchStage: true}),
    next: () => $('#curation-next').click(),
    prev: () => $('#curation-prev').click(),
    goById: id => { const step = byId.get(id); if (step) setCurrent(step.index, true, true); },
    playCue: id => { const cue = cuesById.get(id); if (cue) playCue(cue, true); },
    seek: deliberateSeek,
    commitCue: id => { const cue = cuesById.get(id); return cue ? commitCue(cue) : Promise.reject(new Error('Unknown cue')); },
    reset: () => {
      cancelTyping();
      state = blankState();
      state.active = true;
      for (const field of data.fields) state.authoredNotes[field.id] = '';
      audio.pause();
      audio.currentTime = 0;
      render(true);
    },
    audio
  });

  const stage3 = $('.curation-stage-item[data-stage="podcast"]');
  stage3.disabled = false;
  $('.curation-stage-count', stage3).textContent = `${state.completedIds.length}/${steps.length}`;
  window.podcastArchitectureVersion2016 = data.architectureVersion;
  if (state.active && isCurationOpen()) enter();
})();

//# sourceURL=2016-b2-stage3-controller.js
